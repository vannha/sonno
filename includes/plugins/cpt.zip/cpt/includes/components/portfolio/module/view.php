<?php
// Setup Instance for view
$instance = spyropress_clean_array( $instance );

$filters = '';

$filter = ( isset( $instance['settings'] ) && in_array( 'filters', $instance['settings'] ) ) ? true : false;
$instance['pagination'] = ( isset( $instance['settings'] ) && in_array( 'pagination',$instance['settings'] ) );

if( $filter ) {
    $terms = get_terms( 'portfolio_category' );
    if( !empty( $terms ) && !is_wp_error( $terms ) ) {
        wp_enqueue_script( 'jquery-isotope' );

        echo '<ul class="filter-items" data-option-key="filter"><li><a href="#" data-filter="" class="selected"><span>All</span></a></li>';
            foreach( $terms as $item ){
                echo '<li><a href="#" data-filter=".' . $item->slug . '"><span>' . esc_html( $item->name ) . '</span></a></li>';
            }            
        echo '</ul>';

    }

}

// tempalte
$tmpl = '{content}{pagination}';
    
echo '<div id="masonry" class="masonry isotope"><div class="grid-sizer col-md-3 col-sm-4 col-xs-6"></div>'. $this->query( $instance, $tmpl ) .'</div>';