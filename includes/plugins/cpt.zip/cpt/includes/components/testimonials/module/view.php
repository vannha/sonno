<?php
// Setup Instance for view
$spyropress_instance = spyropress_clean_array( $spyropress_instance );

//Print Html Contents
echo '<div id="testimonail" class="testimonial">'. $this->query( $spyropress_instance, '{content}' ) .'</div>';
    
