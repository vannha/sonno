<?php
// Setup Instance for view
$instance = spyropress_clean_array( $instance );

    echo '<div class="direction">
            <div class="direction-nav">
                <span class="direct-prev prev-team"><i class="icon-arrow-left2"></i></span>
                <span class="direct-next next-team"><i class="icon-arrow-right2"></i></span>
            </div>    
          </div>';
    //content.
    echo '<div id="team-list" class="owl-carousel owl-theme team-list">'. $this->query( $instance, '{content}' ) .'</div>';