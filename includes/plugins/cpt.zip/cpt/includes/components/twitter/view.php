<?php 
	if (isset($username)) {
		$tweets = $this->get_tweets( $username, $twitter_counts );
	    if ( ! empty( $tweets ) ) {
	        echo '<div class="col-md-10 col-md-offset-1 text-center"><span class="icon icon-twitter4 title-icon-primary"></span><div id="tweecool"><ul class="twitter-feed">';
	        foreach ( $tweets as $tweet ) {
	        
	         $text = str_replace( '@envato_help', '', $tweet->text );
	            
	            echo '<li><div class="tweets_txt">'. $text .'<br/><time class="date">'. human_time_diff( strtotime($tweet->created_at), current_time('timestamp') ) .' ago </time></div></li>';
	            
	        }  
	        echo '</ul></div></div>';
	    }	
	}